# Credits

Icons from [Eva Icons](https://akveo.github.io/eva-icons/#/) are published under the [MIT License](http://www.opensource.org/licenses/mit-license.php).