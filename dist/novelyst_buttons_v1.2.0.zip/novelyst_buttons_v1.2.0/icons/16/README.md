# Credits

[Lock icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/lock)

[Save icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/save)

[Refresh icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/refresh)

[Files and folders icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/files-and-folders)

[Paper icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/paper)

[Info icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/info)

[Cancel icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/cancel)

[Back icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/back)

[Next icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/next)
